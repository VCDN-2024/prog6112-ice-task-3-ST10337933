package icetask3;

import java.util.Scanner;

// Abstract class for Workout
abstract class Workout {
    protected String exercises;
    protected int duration; // in minutes
    protected int intensityLevel;

    // Constructor to initialize workout details
    public Workout(String exercises, int duration, int intensityLevel) {
        this.exercises = exercises;
        this.duration = duration;
        this.intensityLevel = intensityLevel;
    }

    // Get methods
    public String getExercises() {
        return exercises;
    }

    public int getDuration() {
        return duration;
    }

    public int getIntensityLevel() {
        return intensityLevel;
    }
}

// Interface for workout
interface IWorkout {
    void printWorkout();
}

// Class that processes the workout
class ProcessWorkout extends Workout implements IWorkout {
    // Constructor
    public ProcessWorkout(String exercises, int duration, int intensityLevel) {
        super(exercises, duration, intensityLevel);
    }

    // Method to print workout details
    @Override
    public void printWorkout() {
        System.out.println("Workout Details:");
        System.out.println("Exercises: " + getExercises());
        System.out.println("Duration: " + getDuration() + " minutes");
        System.out.println("Intensity Level: " + getIntensityLevel());
    }
}

// Main application class
public class Icetask3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt user for workout details
        System.out.print("Enter the exercises (comma-separated): ");
        String exercises = scanner.nextLine();

        System.out.print("Enter the duration (in minutes): ");
        int duration = scanner.nextInt();

        System.out.print("Enter the intensity level (1-10): ");
        int intensityLevel = scanner.nextInt();

        // Create a ProcessWorkout instance
        ProcessWorkout workout = new ProcessWorkout(exercises, duration, intensityLevel);

        // Print the workout details
        workout.printWorkout();

        // Close the scanner
        scanner.close();
    }
}
